<template>
  <div class="dashboard-container">
    <div class="dashboard-editor-container">
      <!-- 内部块的背景颜色用#fff -->
    </div>
  </div>
</template>

<script>

export default {
  name: 'Dashboard',
  components: {
  },
  data() {
    return {
    }
  },
  methods: {
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  .dashboard-editor-container {
    padding: 32px;
    background-color: rgb(240, 242, 245);
    position: relative;
  }
</style>
